#include<stdio.h>
void test_hello(){
	printf("hello, world!\n");	

}
